package com.niit.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.niit.model.Employee;

public class EmployeeDAO {
	public Session m1 (){
		Configuration cfg=new Configuration();
		cfg.configure("hibernate-cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		return s;
	}
	
	public void add(Employee e){
		Session s=m1();
		
		Transaction t=s.beginTransaction();
		s.persist(e);
		t.commit();
		s.close();
	}
	
	public List<Employee> viewEmployee(){
		Session s=m1();
		/*Query q=s.createQuery("from employee");
		List<Employee> list=q.list();*/
		
		List<Employee> list=(List<Employee>)s.createQuery("from Employee").list();
		return list;
	}
	public void updateEmployee(String employeeName,int employeeId) {
		
		Session s=m1();
		Transaction t=s.beginTransaction();
		Query q=s.createQuery("update Employee set employeeName=:employeeName where employeeId=:employeeId");
		q.setString("employeeName", employeeName);
		q.setInteger("employeeId",employeeId);
		q.executeUpdate();
		t.commit();
		s.close();
		
	}
	public void deleteEmployee(int employeeId){
		
		Session s=m1();
		Transaction t=s.beginTransaction();
		Query q=s.createQuery("delete from Employee where employeeId=:employeeId");
		q.setInteger("employeeId", employeeId);
		q.executeUpdate();
		t.commit();
		s.close();
	
	}
	
	
}
