package com.niit.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.niit.DAO.ChangePasswordDAO;

/**
 * Servlet implementation class ChangePassword
 */
@WebServlet("/ChangePassword")
public class ChangePassword extends HttpServlet {
	
	public  static boolean matchPassword(String password,String confirmPassword){
		if(password.equals(confirmPassword))
			return true;
			else {
				System.out.println("password Donot match");
				return false;
			}
				
}
				

			
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String username=(String)session.getAttribute("user");
		String password=request.getParameter("password");
		String cpassword=request.getParameter("cpassword");
		ChangePasswordDAO cp=new ChangePasswordDAO();
		System.out.println(username+ "  " +password+"  "+cpassword);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		if(username==null){
			out.println("<body background='register.jpg'>");
			out.println("<h2><font color='red'>Invalid Cannot Change the password !</font><h2/>") ;
			out.println("</body>");
			RequestDispatcher rd=request.getRequestDispatcher("changePassword");
			rd.include(request, response);
		}else{
		if(matchPassword(password,cpassword) && cp.update(password, username )){
			{
			out.println("<body background='register.jpg'>");
			out.println("<h3><font color='yellow'>your Password is updated</font></h3>") ;
			out.println("<a href='index.jsp'><strong><font color='yellow'>To login click here...<yellow></strong></a>");
			out.println("</body>");
			username=null;
			session.invalidate();
			} 
		}
		else
		{  out.println("<body background='register.jpg'>");
			out.println("<h2><font color='red'>your password donot match!</font><h2/>") ;
			out.println("</body>");
			RequestDispatcher rd=request.getRequestDispatcher("changePassword.jsp");
			rd.include(request, response);
		}
		}
		

	}
}