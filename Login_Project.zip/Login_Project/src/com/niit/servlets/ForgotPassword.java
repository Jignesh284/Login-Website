package com.niit.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.niit.DAO.ForgotPasswordDAO;

/**
 * Servlet implementation class ForgotPassword
 */
@WebServlet("/ForgotPassword")
public class ForgotPassword extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String food=request.getParameter("food");
		String username=request.getParameter("username");
		response.setContentType("text/html");
		ForgotPasswordDAO fd=new ForgotPasswordDAO();
		boolean answer=fd.validateFood(food,username);
		System.out.println(answer);
		if(answer){
			HttpSession session=request.getSession();
			session.setAttribute("user", username);
			RequestDispatcher rd=request.getRequestDispatcher("changePassword.jsp");
			rd.forward(request,response);
		}
		else{
			PrintWriter out=response.getWriter();
			out.println("<body background='register.jpg'>");
			out.println("<font color='red'>Please enter correct answer!</font>");
			out.println("</body>");
			RequestDispatcher rd=request.getRequestDispatcher("forgotPassword.jsp");
			rd.include(request,response);
		}
		
	}

	
	

}
