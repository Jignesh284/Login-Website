package com.niit.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.niit.DAO.LoginDAO;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		LoginDAO ld=new LoginDAO();
		System.out.println("In login servlet "+username+ " "+password);
		boolean answer=ld.validate(username, password);
		
		PrintWriter out=response.getWriter();
		RequestDispatcher rd;
		response.setContentType("text/html");
		
		if(answer){
			rd=request.getRequestDispatcher("home.jsp");
			HttpSession session=request.getSession();
			String name=ld.getName(username, password);
			session.setAttribute("user", name);
			System.out.println();
			rd.forward(request,response);
		
		}else{
			out.println("<h2><font color='red'>Invalid User!</font></h2>");
			rd=request.getRequestDispatcher("index.jsp");
			rd.include(request, response);
		
		}
	
	}
	

}
