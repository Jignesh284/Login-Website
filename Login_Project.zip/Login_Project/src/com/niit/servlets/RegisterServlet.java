package com.niit.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.niit.DAO.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	
	public  static boolean matchPassword(String password,String confirmPassword){
		if(password.equals(confirmPassword))
			return true;
			else {
				System.out.println("password Donot match");
				return false;
				}
			}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstname=request.getParameter("fname");
		String lastname=request.getParameter("lname");
		String address=request.getParameter("address");
		String food=request.getParameter("food");
		String gender=request.getParameter("gender");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String cpassword=request.getParameter("cpassword");
		String role="user";
		boolean enabled=true;
		response.setContentType("text/html");
	    
		PrintWriter out=response.getWriter();
		
	    
		RegisterDAO ro=new RegisterDAO();
		if(ro.checkUserExists(username)){
			out.println("<font color='red'><h3>Username Already Exist</font></h3>");
			out.println("<strong><font color='red'>you should use some other user name or try forgot password</font></strong>");
			out.println("<a href='forgotPassword.jsp'>Forgot Password</a>");
			RequestDispatcher rd=request.getRequestDispatcher("register.jsp");
			rd.include(request, response);
			
		}
		else{
			boolean answer=matchPassword(password,cpassword);
		
			if(!answer){
				
					out.println("<body background='register.jpg'>");
					out.println("<h3><font color='red'>your Password donot match</h3>") ;
			
					out.println("</body>");
					RequestDispatcher rd=request.getRequestDispatcher("register.jsp");
					rd.include(request, response);
				
					}
			else{  
					boolean flag=ro.add(username, password, firstname, lastname, address, gender, role, enabled, food);
					if(flag){
							out.println("you Are Registered successfully");
							out.println("<a href='index.jsp'>Click here  to login..</a>");
						}
					else{
						out.println("Sorry we were unable to register you.");
						out.println("<a href='register.jsp'>Click here  to register again..</a>");
		  
						}
			
				}
	
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	

}
