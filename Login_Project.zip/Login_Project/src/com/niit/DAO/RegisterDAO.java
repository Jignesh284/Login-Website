package com.niit.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RegisterDAO {
	
	public static Connection makeConnection() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/webdatabase","root","root");
	}
	
	public boolean add (String username,String password,String firstname,String lastname,String address,String gender,String role,boolean enabled,String food){
		
		
		
		try{
			
			Connection conn=makeConnection();
			String sql="insert into users(username,password,firstname,lastname,address,gender,role,enabled,food) Values (?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,username);	
			ps.setString(2, password );
			ps.setString(3, firstname );
			ps.setString(4, lastname );
			ps.setString(5, address);
			ps.setString(6,gender);
			ps.setString(7,role);
			ps.setBoolean(8,enabled);
			ps.setString(9, food);
			ps.executeUpdate();
			System.out.println("user Added in the DATABASE");
			return true;
		
		}
		catch(Exception e){
			e.printStackTrace();
			}
		return false;
	}
	

	public boolean checkUserExists(String username) {
		// TODO Auto-generated method stub
		try {
			Connection conn=makeConnection();
			String sql="select * from users where username=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, username);
			ResultSet rs=ps.executeQuery();
			if(rs.first()){
				System.out.println("user already exists");
				return true;
			}
		} catch (ClassNotFoundException|SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}

}
/*("username","password","firstname","lastname","address","gender","role","enabled","food")*/