package com.niit.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDAO {
	// makes connection and return Connection refrence
	public static Connection makeConnection() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/webdatabase","root","root");
	}
	
	//methed to check weather username and password matches or not
public boolean validate(String username,String password)
{
	try{
		
		Connection conn=makeConnection();
		PreparedStatement ps=conn.prepareStatement("select * from users where username=? and password=?");
		ps.setString(1, username);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		if(rs.first()){
			return true;
		}
		else return false;
	}catch(Exception e){
		e.printStackTrace();
		}
	return false;
	}

//returns the name of user  for new login page
public String getName(String username,String password){
	ResultSet rs;
	try {
		Connection conn=makeConnection();
		String sql="select firstname from users where username=? and Password=?";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1, username);
		ps.setString(2, password);
		rs=ps.executeQuery();
		System.out.println("the query is executed");
		rs.next();
		return (String)rs.getString("firstname");
		
	} catch (ClassNotFoundException|SQLException e) {
		
		e.printStackTrace();
	}
	
	return null;
}

}

