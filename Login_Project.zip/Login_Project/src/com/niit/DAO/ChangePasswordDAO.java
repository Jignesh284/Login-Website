package com.niit.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ChangePasswordDAO {
	public static Connection makeConnection() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/webdatabase","root","root");
	}
	
	//query to update string
	public boolean update (String password,String username) {
		
		try {
			Connection conn=makeConnection();
			String sql="UPDATE users SET password=?  WHERE username=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, password);
			ps.setString(2, username);
			ps.executeUpdate();
			return true;
		} catch (ClassNotFoundException|SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		return false;
	}

}
