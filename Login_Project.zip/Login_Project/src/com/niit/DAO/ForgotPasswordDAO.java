package com.niit.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ForgotPasswordDAO {
	
	public static Connection makeConnection() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/webdatabase","root","root");
	} 
	//checks if the security answer matches or not
	public boolean validateFood(String food,String username) {
		// TODO Auto-generated method stub
		
		try {
			Connection conn=makeConnection();
			String sql="select * from users where username=? and food=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,username);
			ps.setString(2, food);
			ResultSet rs=ps.executeQuery();
			if(rs.first()){
				return true;
			}
			else return false;
			
		} catch (ClassNotFoundException|SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return false;
	}

}
